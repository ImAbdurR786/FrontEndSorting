import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  service: BookService;
  
Products: String[] = ["Laptop","Mobile","Telephone"];
Sorting: String[] = ["Sorting","Laptop","Mobile","Telephone"];
router: Router;
  constructor(service: BookService, router: Router) {
    this.service = service;
  this.router =router; 
  }

  add(){
    console.log("Ascen");
 //   this.service.add(data);
   }
   
   cart(){
    this.router.navigate(['/display']);
  }
  ngOnInit() {
  }

}
