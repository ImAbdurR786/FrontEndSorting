import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { DisplayComponent } from './display/display.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BookService } from './book.service';
import { AddComponent } from './add/add.component';
import { UpdateComponent } from './update/update.component';
import { OrderbyPipe } from './orderby.pipe';

@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    AddComponent,
    UpdateComponent,
    OrderbyPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,BookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
