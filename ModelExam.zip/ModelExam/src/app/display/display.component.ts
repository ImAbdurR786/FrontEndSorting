import { Component, OnInit } from '@angular/core';
import { BookService} from '../book.service';
import { Book } from '../book';
import { Router } from '@angular/router';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  service:BookService;
  bookArr: Book[] = [];
  Products:String[] = ["Abc"];
  constructor(service:BookService) {
    this.service = service;
  }

  ngOnInit() {
    this.service.fetchData();
    this.bookArr = this.service.getData();
  }

  delete(data:any){
    this.service.delete(data);
    this.bookArr = this.service.getData();
  }

  Isupdate: boolean = true;
  update(){
    this.Isupdate = !this.Isupdate;
  }

  Updates(data:any){
    let book = new Book(data.updId,data.updName);
    this.service.updt(book);
  }

  Issearch: boolean = true;
  search(){
    this.Issearch = !this.Issearch;
  }

  BookSearch: Book[] = [];
  genre  = ["id","name"]; 

  Searchs(data:any){
    this.BookSearch = this.service.search(data);
  }

  column:string = "id";
  order:boolean = true;
  
  sort(column: string){
  
    if(this.column == column){
      this.order = !this.order;
    }
    else{
      this.order = true;
      this.column = column;
    }
  }
}
