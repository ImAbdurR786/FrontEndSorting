import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  http: HttpClient;
  fetch: boolean = false;
  book: Book;
  bookArray: Book[] = [];
  

  constructor(http: HttpClient) {
    this.http = http;
   }

   fetchData(){
     this.http.get('./assets/Books.json')
     .subscribe(data =>{
       if(!this.fetch){
         this.convert(data);
         this.fetch = true;
       }
     })
   }

   convert(data:any){
     
     for(let book of data["Books"]){
       this.book = new Book(book.id,book.name);
       this.bookArray.push(this.book);
     }
   }

   getData(): Book[]{
     return this.bookArray;
   }

   delete(data:any){

    let foundIndex:number = -1;
    for(let i=0; i< this.bookArray.length; i++){
      let refbook = this.bookArray[i];
      if(refbook.name==data){
        foundIndex = i;
        break;
      }
    }
    this.bookArray.splice(foundIndex,1);
   }

   add(data:any){
     let book = new Book(data.addId,data.addName);
     this.bookArray.push(book);
   }

   updt(data:Book){
     for(let i=0; i<this.bookArray.length; i++){
       let book = this.bookArray[i];
       
       if(book.id==data.id){
          book.name = data.name;
       }
     }
   }

   BookSearch: Book[];
   
   search(data:any){
     this.BookSearch = [];
     for(let i=0; i<this.bookArray.length; i++){
       let book = this.bookArray[i];
       console.log(data.searchID);
       console.log(book.id);
       if( data.searchID == book.id){
         this.BookSearch.push(book);} 
     }
     return this.BookSearch;
   }

}

